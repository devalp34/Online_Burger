import React from 'react';

 const more = (props) => {
     return (
        <div>
        {props.children}
        </div>
     )
}

export default more;