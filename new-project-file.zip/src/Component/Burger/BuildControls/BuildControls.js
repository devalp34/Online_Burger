import React from 'react';
import classes from './BuildControls.css';
import BuildControl from './BuildControl/BuildControl';

const control = [
    {label: 'Salad',type : 'salad'},
    {label: 'Meat',type : 'meat'},
    {label: 'Cheese',type : 'cheese'},
    {label: 'Bacon',type : 'bacon'}
]

const BuildControls = (props) => (
    <div className = {classes.BuildControls}>
        <p> Your total price is $ <strong>{props.price.toFixed(2)}</strong></p>
        {control.map(ctrl => {
            return <BuildControl 
                        key = {ctrl.label} 
                        label = {ctrl.label} 
                        addedItem = {() => props.addItem(ctrl.type)}
                        removedItem = {() => props.removeItem(ctrl.type)}
                        priced = {props.price}
                        disabled = {props.disabled[ctrl.type]}/>
        })}
        <button className = {classes.OrderButton}
                disabled = {!props.purchasable}
                onClick = {props.clicked}> 
                Order It!!</button>
    </div>
)

export default BuildControls;