import React from 'react';
import classes from './DirectionItems.css';
import DirectionItem from './DirectionItem/DirectionItem';

const DirectionItems = (props) => (
    <ul className = {classes.DirectionItems}> 
        <DirectionItem link = "/" >
             BurgerBuilder
        </DirectionItem>
        <DirectionItem link = "/orders" >
             Orders
        </DirectionItem>
    </ul>
)

export default DirectionItems;