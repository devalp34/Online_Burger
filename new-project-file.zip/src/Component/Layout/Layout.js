import React,{Component} from 'react';
import More from '../../hoc/More'
import Classes from './Layout.css';
import Toolbar from '../Directions/Toolbar/Toolbar';
import SideDrawer from '../Directions/SideDrawer/SideDrawer';

class Layout extends Component{
    state = {
        ShowDrawer : true,
    }

    SDCloseHandler = () => {
        this.setState ({ShowDrawer : false});
        console.log("From Handler",this.state.ShowDrawer)
    }

    clickHanadler = () => {
        this.setState((prevState) => {
            return {ShowDrawer : !prevState.ShowDrawer}
    })
}

    render() {
        return (
            <More>
                <Toolbar
                    click = {this.clickHanadler}
                    btn = {this.state.toggleButton}/> 
                <SideDrawer
                    open = {this.state.ShowDrawer} 
                    clicked = {this.SDCloseHandler}/>
            <main className = {Classes.Content}> 
                {this.props.children} 
            </main>
          </More> 
        )
    }
}; 

export default Layout;