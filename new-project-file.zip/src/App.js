import React, { Component } from 'react';
import {Route,Switch} from 'react-router-dom';

import Layout from './Component/Layout/Layout';
import './App.css';
import BurgerBuilder from './Container/BurgerBuilder/BurgerBuilder';
import CheckOut from './Container/CheckOut/CheckOut';
import Orders from './Container/Orders/Orders';

class App extends Component {


  render() {
    return (
      <div>
      <Layout>
        <Switch>
          <Route path = "/checkout" component = {CheckOut} /> 
          <Route path = "/" exact component = {BurgerBuilder} />
          <Route path = "/orders" exact component = {Orders} />
        </Switch>
      </Layout>
      </div>
    );
  }
}

export default App;
