import React , {Component} from 'react';

import Order from '../../Component/Order/Order'
import axios from '../../Axios';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';

class Orders extends Component{

    state = {
        loading : true,
        orders : []
    }
    componentDidMount() {
        axios.get("/orders.json")
             .then(res => {
                 const fetchedOrders = []
                 for(let key in res.data){
                     console.log(key)
                     fetchedOrders.push({
                         ...res.data[key],
                         id : key
                     })
                 }
                this.setState({loading : false, orders : fetchedOrders})
             })
             .catch(err => console.log(err))
    }
    render() {
        console.log("from orders.js :",this.state.orders)
        return(
            <div> 
                {this.state.orders.map(order =>( 
                    <Order
                        key = {order.id} 
                        ingrediants = {order.ingrediant}
                        price = {+order.price}/>
                ))}
                {/* <Order />
                <Order /> */}
            </div>
        )
    }
}

export default withErrorHandler(Orders,axios)