import React, {Component} from 'react';
import More from '../../hoc/More';
import Burger from '../../Component/Burger/Burger';
import BuildControls from '../../Component/Burger/BuildControls/BuildControls';
import Modal from '../../Component/FrontEnd/Model/Model';
import OrderSummary from '../../Component/Burger/OrderSummary/OrderSummary';
import axios from '../../Axios';
import Spinner from '../../Component/FrontEnd/Spinner/Spinner';
import WithErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';

const INGREDIANT_PRICE = {
    salad : 0.5,
    cheese : 0.4,
    meat : 1.3,
    bacon : 0.6
}

class BurgerBuilder extends Component {

    state = {
        ingrediant: null,
        totalPrice : 4,
        purchasable : false,
        shopping :false,
        loading : false,
        error : null
    }

    componentDidMount (){
        axios.get('https://magic-burger-838b0.firebaseio.com/dish.json')
             .then(request => {
                 this.setState({ingrediant : request.data})
             })
             .catch(error => {
                 this.setState({error : error})
             })
    }

    purchasableIngrediant = (ingrediant) => {
        const sum = Object.keys(ingrediant)
                    .map(igkey => {
                        return ingrediant[igkey];
                    })
                      .reduce((sum,el) => {
                        return sum + el
                      },0);

        this.setState({purchasable : sum > 0})
    }

    addIngrediant = (type) => {
        const oldTotal = this.state.ingrediant[type];
        const updatedTotal = oldTotal + 1;
        const updatedIngrediant = {...this.state.ingrediant};
        updatedIngrediant[type] = updatedTotal
        const updatedPrice = this.state.totalPrice + INGREDIANT_PRICE[type];
        this.setState({totalPrice : updatedPrice , ingrediant : updatedIngrediant});
        this.purchasableIngrediant(updatedIngrediant)
    }

    removeIngrediant = (type) => {
        const oldTotal = this.state.ingrediant[type];
        if(oldTotal <= 0)
        {
            return;
        }
        const updatedTotal = oldTotal - 1;
        const updatedIngrediant = {...this.state.ingrediant};
        updatedIngrediant[type] = updatedTotal
        const updatedPrice = this.state.totalPrice - INGREDIANT_PRICE[type];
        this.setState({totalPrice : updatedPrice , ingrediant : updatedIngrediant});
        this.purchasableIngrediant(updatedIngrediant)
    }

    purchaseHandler = () => {
        this.setState({shopping : true})
    }

    purchaseCancelHandler = () => {
        this.setState({shopping : false})
    }

    purchaseContinueHandler = () => {
        const queryParams = [];
        for(let i in this.state.ingrediant){
            queryParams.push(encodeURIComponent(i) + "=" + encodeURIComponent(this.state.ingrediant[i]))
        }
        queryParams.push("price="+this.state.totalPrice)
        const queryString = queryParams.join('&')
        this.props.history.push({
            pathname : '/checkout',
            search : '?'+ queryString
        })
    }


    render(){
        const disabledInfo = {
            ...this.state.ingrediant
        }

        for(let key in disabledInfo){
            disabledInfo[key] = disabledInfo[key] <= 0
        }

        let orderSummary = null;
        if(this.state.ingrediant){
            orderSummary = <OrderSummary 
                                ingrediant = {this.state.ingrediant}
                                continue = {this.purchaseContinueHandler}
                                cancel = {this.purchaseCancelHandler}
                                price = {this.state.totalPrice}/>
        }
                            
        if(this.state.loading){
            orderSummary = <Spinner />
        }

        let burger = this.state.error ? <p> Ur Ingrediant cant be loaded</p> : <Spinner />
        if(this.state.ingrediant){
            burger =<More>
                        <Burger ingrediant = {this.state.ingrediant}/>
                        <BuildControls  
                            addItem = {(type) => this.addIngrediant(type)}
                            removeItem = {(type) => this.removeIngrediant(type)}
                            price = {this.state.totalPrice}
                            purchasable = {this.state.purchasable}
                            disabled = {disabledInfo}
                            clicked = {this.purchaseHandler}/> 
                    </More>
        }

        return (
                <More>
                    <Modal show = {this.state.shopping}
                            modalClick = {this.purchaseCancelHandler}>
                            {orderSummary}
                    </Modal>
                    {burger}
                </More>    
        )
    }
}

export default WithErrorHandler(BurgerBuilder,axios);