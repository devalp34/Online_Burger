import React ,{Component} from 'react';
import {Route} from 'react-router-dom';

import ContactData from '../ContactData/ContactData';
import CheckoutSummary from '../../Component/Order/CheckoutSummary';

class CheckOut extends Component {
    state = {
        ingrediants : null,
        TotalPrice : 0
    }
    
    onCheckoutCanceclled = () => {
        console.log("from go back")
        this.props.history.goBack()
    }

    onCheckoutContinued = () => {
        this.props.history.replace('/checkout/contact-data')
    }

    componentWillMount () {
        const query = new URLSearchParams(this.props.location.search);
        const ingrediants = {}    
        let price = 0;
        for(let i of query.entries()){
            if(i[0] === "price"){
                price = i[1]
            }else {
                ingrediants[i[0]] = +i[1];
            }
        }  
        this.setState({ingrediants : ingrediants, totalPrice : price})
        // console.log(this.props.location.search)
    }

    render() {
        return(
        <div>
            <CheckoutSummary 
                ingrediant = {this.state.ingrediants}
                checkoutCancelled = {this.onCheckoutCanceclled}
                checkoutContinued = {this.onCheckoutContinued}/>
                <Route path = {this.props.match.path + "/contact-data"}
                        render = {(props) => (<ContactData
                                            ingrediants = {this.state.ingrediants}
                                            price = {this.state.totalPrice}
                                            {...props}/>)}
                                            />
        </div>
        )
    }
}

export default CheckOut;